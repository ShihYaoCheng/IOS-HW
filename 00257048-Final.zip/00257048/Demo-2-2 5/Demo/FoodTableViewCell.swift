//
//  FoodTableViewCell.swift
//  Demo
//
//  Created by user_02 on 2017/1/9.
//  Copyright © 2017年 Peter Pan. All rights reserved.
//
import UIKit

class FoodTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
